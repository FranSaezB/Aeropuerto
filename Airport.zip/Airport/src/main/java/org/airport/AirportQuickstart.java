
package org.airport;

import java.io.IOException;

import org.airport.controller.AirportController;
import org.airport.controller.AirportInteraction;
import org.airport.controller.TerminateExecutionCommand;
import org.airport.simulator.AirportSimulator;
import org.airport.simulator.SimulatorInteraction;
import org.airport.simulator.StartSimulationCommand;
import org.airport.simulator.StopSimulationCommand;

import akka.actor.typed.ActorSystem;

public class AirportQuickstart {
	public static void main(String[] args) {

		// Creation of the actor-systems

		// airportController
		final ActorSystem<AirportInteraction> airportController = ActorSystem.create(AirportController.create(),
				"airport");

		final ActorSystem<SimulatorInteraction> airportSimulator = ActorSystem
				.create(AirportSimulator.create(airportController), "simulator");

		// Message to initialize the program (sending the size of the conveyor)

		airportSimulator.tell(new StartSimulationCommand("Barajas", 8));

		try {
			System.out.println(">>> Press ENTER to exit <<<\n");
			System.in.read();
		} catch (IOException ignored) {
		} finally {

			// When the user presses ENTER in the console
			// The system starts a Gratefull stop for both actor systems and their
			// childs

			airportController.tell(new TerminateExecutionCommand());

			airportSimulator.tell(new StopSimulationCommand());

		}
	}
}
