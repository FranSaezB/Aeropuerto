package org.airport;

public class Passenger {

	private final String id;
	
	private int suitcases;
	
	
	public Passenger(String id, int suitcases) {
		
		this.id = id;
		
		this.suitcases = suitcases;
		
	}
	
	public String getId() {
		return id;
	}
	
	public int getSuitcases() {
		return suitcases;
	}

	public void setSuitcases(int suitcases) {
		this.suitcases = suitcases;
	}
	

}
