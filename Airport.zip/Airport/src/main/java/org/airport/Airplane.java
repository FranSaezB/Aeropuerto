package org.airport;

public class Airplane {

	private int suitcaseCounter;

	public Airplane() {
		super();
		this.suitcaseCounter = 0;
	}

	public int getSuitcaseCounter() {
		return suitcaseCounter;
	}

	public void setSuitcaseCounter(int suitcaseCounter) {
		this.suitcaseCounter = suitcaseCounter;
	}

}
