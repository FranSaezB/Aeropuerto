package org.airport.simulator;

public class PassengerStopped implements SimulatorInteraction {

}
