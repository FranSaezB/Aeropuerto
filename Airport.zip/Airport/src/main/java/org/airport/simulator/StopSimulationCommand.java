package org.airport.simulator;

public class StopSimulationCommand implements SimulatorInteraction {

}
