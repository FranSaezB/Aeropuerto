package org.airport.simulator;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.airport.Passenger;
import org.airport.controller.rowManager.PassengersNotification;

import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

public class PassengerSimulator extends AbstractBehavior<SimulatorInteraction> {

	public static Behavior<SimulatorInteraction> create() {
		return Behaviors.setup(PassengerSimulator::new);
	}

	private PassengerSimulator(ActorContext<SimulatorInteraction> context) {
		super(context);
		this.getContext().getSystem();

	}

	@Override
	public Receive<SimulatorInteraction> createReceive() {

		return newReceiveBuilder().onMessage(SimulateStartArrivals.class, this::onStartArrivals)
				.onMessage(StopSimulationCommand.class, this::onStopSimulationCommand).build();
	}

	private Behavior<SimulatorInteraction> onStopSimulationCommand(StopSimulationCommand command) {

		return Behaviors.stopped();
	}

	private Behavior<SimulatorInteraction> onStartArrivals(SimulateStartArrivals command) {

//		System.out.println("PassengerSimulator.onStartArrivals (" + command + " )");

		while (LocalDateTime.now().isBefore(command.getUntil())) {

			int amount = (int) Math.round(Math.random() * 10);

			List<Passenger> passengers = createRandomPassengers(amount);

			command.getAirportController().tell(new PassengersNotification(passengers));

		}

		return this;
	}

	private List<Passenger> createRandomPassengers(int amount) {

		List<Passenger> passengers = new ArrayList<>();

		int rand;

		Passenger passenger;

		for (int i = 0; i < amount; i++) {

			rand = ((int) Math.round(Math.random() * 10) % 3) + 1;

			passenger = new Passenger("Pasajero " + i, rand);

			passengers.add(passenger);

		}

		return passengers;
	}
}
