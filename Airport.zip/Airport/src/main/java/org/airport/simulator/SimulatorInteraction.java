package org.airport.simulator;

import org.airport.controller.AirportInteraction;

public interface SimulatorInteraction extends AirportInteraction {

}
