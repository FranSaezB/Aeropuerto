package org.airport.simulator;

import java.time.Duration;
import java.time.LocalDateTime;

import org.airport.controller.AirportInteraction;
import org.airport.controller.OpenAirport;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

public class AirportSimulator extends AbstractBehavior<SimulatorInteraction> {

	private final ActorRef<AirportInteraction> airportController;
	private final ActorRef<SimulatorInteraction> passengerSimulator;

	public static Behavior<SimulatorInteraction> create(ActorRef<AirportInteraction> airportController) {
		return Behaviors.setup(param -> {
			return new AirportSimulator(param, airportController);
		});
	}

	private AirportSimulator(ActorContext<SimulatorInteraction> context,
			ActorRef<AirportInteraction> airportController) {
		super(context);
		this.getContext().getSystem();
		this.airportController = airportController;
		// #create-actors
		// #create-actors
		passengerSimulator = context.spawn(PassengerSimulator.create(), "passengerSimulator");

		this.getContext().watchWith(passengerSimulator, new PassengerStopped());

	}

	@Override
	public Receive<SimulatorInteraction> createReceive() {

		return newReceiveBuilder().onMessage(StartSimulationCommand.class, this::onStartSimulation)
				.onMessage(StopSimulationCommand.class, this::onStopSimulationCommand)
				.onMessage(PassengerStopped.class, this::onPassengerStopped).build();
	}

	private Behavior<SimulatorInteraction> onStopSimulationCommand(StopSimulationCommand command) {

		System.out.println("NOTIFICATION TO STOP SIMULATOR");

		// this.getContext().stop(passengerSimulator);

		passengerSimulator.tell(command);

		return this;
	}

	private Behavior<SimulatorInteraction> onPassengerStopped(PassengerStopped command) {

		System.out.println("TERMINATING SIMULATOR\n");

		this.getContext().getSystem().terminate();
		
		return Behaviors.stopped();
	}

	private Behavior<SimulatorInteraction> onStartSimulation(StartSimulationCommand command) {
		// #create-actors
		System.out.println("STARTING THE PASSENGER SIMULATOR\n");

		airportController.tell(new OpenAirport(command.name, command.size, this.getContext().getSelf()));
		// #create-actors
		passengerSimulator
				.tell(new SimulateStartArrivals(airportController, LocalDateTime.now().plus(Duration.ofMillis(10))));
		return this;
	}
}
