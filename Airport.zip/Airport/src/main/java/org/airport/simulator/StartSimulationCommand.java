package org.airport.simulator;

public class StartSimulationCommand implements SimulatorInteraction {

	public final int size;
	public final String name;

	public StartSimulationCommand(String name, int size) {
		super();
		this.size = size;
		this.name = name;
	}

	public int getSize() {
		return size;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "OpenAirport [size=" + size + ", name=" + name + "]";
	}

}