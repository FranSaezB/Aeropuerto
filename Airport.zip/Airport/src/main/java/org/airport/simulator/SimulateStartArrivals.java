package org.airport.simulator;

import java.time.LocalDateTime;

import org.airport.controller.AirportInteraction;

import akka.actor.typed.ActorRef;

public class SimulateStartArrivals implements SimulatorInteraction {
	
    public final LocalDateTime until;
    public final ActorRef<AirportInteraction> airportController;

	public SimulateStartArrivals(ActorRef<AirportInteraction> airportController, LocalDateTime until) {
		super();
		this.until = until;
		this.airportController = airportController;
	}
	
	public ActorRef<AirportInteraction> getAirportController() {
		return airportController;
	}
    
    public LocalDateTime getUntil() {
		return until;
	}

	@Override
	public String toString() {
		return "StartArrivals [until=" + until + ", airportController=" + airportController + "]";
	}

	
    
}