package org.airport.controller.conveyor;

import java.util.ArrayList;
import java.util.List;

import org.airport.controller.AirportInteraction;
import org.airport.controller.AirportPrivateInteraction;
import org.airport.controller.ConveyorReady;
import org.airport.controller.DoneTaskNotification;
import org.airport.controller.TerminateExecutionCommand;
import org.airport.controller.employeeManager.AddWorkersRequest;
import org.airport.controller.employeeManager.EmployeeReady;
import org.airport.controller.rowManager.EmptyRow;
import org.airport.controller.rowManager.NextPassengerNotification;
import org.airport.controller.rowManager.NextPassengerRequest;
import org.airport.controller.rowManager.RowsReferencesNotification;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

public class Conveyor extends AbstractBehavior<AirportPrivateInteraction> {

	private ActorRef<AirportPrivateInteraction> employeeManager;
	private ActorRef<AirportInteraction> airportController;
	private List<ActorRef<AirportPrivateInteraction>> rows = new ArrayList<>();
	private List<ActorRef<AirportPrivateInteraction>> slots = new ArrayList<>();
	private List<Integer> slotsIndexes = new ArrayList<>();
	private List<ActorRef<AirportPrivateInteraction>> employees = new ArrayList<>();
	private int rotationCounter = 0;
	private int unavilableEmployeesCounter = 0;
	private int terminatedCounter = 0;
	private int finishedExecution = 0;

	public static Behavior<AirportPrivateInteraction> create(ActorRef<AirportInteraction> airportController) {
		return Behaviors.setup(param -> {
			return new Conveyor(param, airportController);
		});
	}

	private Conveyor(ActorContext<AirportPrivateInteraction> context, ActorRef<AirportInteraction> airportController) {
		super(context);
		this.airportController = airportController;
	}

	@Override
	public Receive<AirportPrivateInteraction> createReceive() {
		return newReceiveBuilder().onMessage(RowsReferencesNotification.class, this::onRowsReferencesNotification)
				.onMessage(InitializeConveyor.class, this::onInitializeConveyor)
				.onMessage(EmptyRow.class, this::onEmptyRow).onMessage(EmployeeReady.class, this::onEmployeeReady)
				.onMessage(DoneTaskNotification.class, this::onDoneTaskNotification)
				.onMessage(NextPassengerNotification.class, this::onNextPassengerNotification)
				.onMessage(TaskNotDoneFilledSlot.class, this::onTaskNotDoneFilledSlot)
				.onMessage(TaskNotDoneEmptySlot.class, this::onTaskNotDoneEmptySlot)
				.onMessage(TerminateConveyorExecution.class, this::onTerminateExecutionCommand)
				.onMessage(SlotStopped.class, this::onSlotStopped).build();
	}

	private Behavior<AirportPrivateInteraction> onTerminateExecutionCommand(TerminateConveyorExecution command) {

		System.out.println("NOTIFICATION TO STOP THE CONVEYOR");

		for (int i = 0; i < slots.size(); i++) {

			slots.get(i).tell(command);

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onSlotStopped(SlotStopped command) {

		System.out.println("Slots stopped: " + (this.terminatedCounter + 1));

		this.terminatedCounter++;

		if (terminatedCounter == slots.size()) {

			System.out.println("STOPPING CONVEYOR");

			return Behaviors.stopped();

		} else {

			return this;

		}

	}

	private Behavior<AirportPrivateInteraction> onEmployeeReady(EmployeeReady command) {

//		System.out.println("Conveyor.onEmployeeReady (" + command + " )");

		employeeManager = command.getAffectedEmployeeManager();

		this.employees.add(command.getAffectedEmployee());

		return this;
	}

	private Behavior<AirportPrivateInteraction> onTaskNotDoneEmptySlot(TaskNotDoneEmptySlot command) {

//		System.out.println("Conveyor.onTaskNotDoneEmptySlot (" + command + " )");

		this.employees.add(0, command.getAffectedEmployee());

		this.rotationCounter++;
		
		this.finishedExecution ++;
		
		if (this.finishedExecution >= 24) {
			
			System.out.println("ALL SUITCASES HAVE BEEN PROCESSED !");
			
			this.airportController.tell(new TerminateExecutionCommand());
			
			
		}

		// System.out.println("Actual value of the counter: "+this.rotationCounter+
		// "empty slot");

		if (this.rotationCounter == 8) {

			rotate();

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onTaskNotDoneFilledSlot(TaskNotDoneFilledSlot command) {

//		System.out.println("Conveyor.onTaskNotDoneFilledSlot (" + command + " )");

		this.rotationCounter++;

		// System.out.println("Actual value of the counter: "+this.rotationCounter+
		// "Filled slot");

		if (this.rotationCounter == 8) {

			rotate();

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onEmptyRow(EmptyRow command) {

//		System.out.println("Conveyor.onEmptyRow (" + command + " )");

		this.rotationCounter++;

		// System.out.println("Actual value of the counter: "+this.rotationCounter+
		// "empty row");

		if (this.rotationCounter == 8) {

			rotate();

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onDoneTaskNotification(DoneTaskNotification command) {

//		System.out.println("Conveyor.onDoneTaskNotification (" + command + " )");

		int affectedSlot = Integer.valueOf(command.getAffectedSlot().substring(4));

		if (slotsIndexes.get(affectedSlot) != 7) {

			rows.get(slotsIndexes.get(affectedSlot)).tell(new SuitcaseProcessed());

		} else {

			this.unavilableEmployeesCounter = 0;

		}

		this.rotationCounter++;

		// System.out.println("Actual value of the counter: "+this.rotationCounter+
		// "Done Task");

		if (this.rotationCounter == 8) {

			rotate();

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onNextPassengerNotification(NextPassengerNotification command) {

//		System.out.println("Conveyor.onNextPassengerNotification (" + command + " )");

		int slot = slotsIndexes.indexOf(command.getAffectedRow());

		slots.get(slot).tell(new LocateSuitcaseRequest());

		return this;
	}

	private Behavior<AirportPrivateInteraction> onRowsReferencesNotification(RowsReferencesNotification command) {

//		System.out.println("Conveyor.onRowsReferencesNotification (" + command + " )");

		this.rows = command.getRowsReferences();

		for (int z = 0; z < rows.size(); z++) {

			rows.get(z).tell(new NextPassengerRequest(this.getContext().getSelf()));
		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onInitializeConveyor(InitializeConveyor command) {

//		System.out.println("Conveyor.onInitializeConveyor (" + command + " )");

		for (int i = 0; i < command.getSize(); i++) {

			slots.add(this.getContext().spawn(Slot.create(this.getContext().getSelf()), "slot" + i));

			this.getContext().watchWith(slots.get(i), new SlotStopped());

			slotsIndexes.add(i);

		}

		if (employees.isEmpty()) {

			this.rotationCounter++;

			// System.out.println("Actual value of the counter: "+this.rotationCounter+
			// "employees empty");

			this.unavilableEmployeesCounter++;

		} else {

			slots.get(slotsIndexes.indexOf(7)).tell(new PickSuitcaseRequest(employees.get(0)));

			employees.remove(0);

		}

		airportController.tell(new ConveyorReady());

		return this;
	}

	private void rotate() {

		System.out.println("ROTATING CONVEYOR !!!!!!!");

		this.rotationCounter = 0;

		for (int i = 0; i < slotsIndexes.size(); i++) {

			slotsIndexes.set(i, slotsIndexes.get(i) + 1);

			if (slotsIndexes.get(i) == slotsIndexes.size()) {

				slotsIndexes.set(i, 0);

			}

		}

		for (int z = 0; z < rows.size(); z++) {

			rows.get(z).tell(new NextPassengerRequest(this.getContext().getSelf()));

		}

		if (employees.isEmpty()) {

			this.rotationCounter++;

			this.unavilableEmployeesCounter++;

			if (unavilableEmployeesCounter >= 4) {

				this.employeeManager.tell(new AddWorkersRequest());

				this.unavilableEmployeesCounter = 0;

			}

		} else {

			slots.get(slotsIndexes.indexOf(7)).tell(new PickSuitcaseRequest(employees.get(0)));

			employees.remove(0);

		}

	}

}
