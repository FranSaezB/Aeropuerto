package org.airport.controller.rowManager;

import org.airport.controller.AirportPrivateInteraction;

public final class PassengerFinished implements AirportPrivateInteraction {

	public final int affectedRow;

	public PassengerFinished(int affectedRow) {
		this.affectedRow = affectedRow;
	}

	public int getAffectedRow() {
		return affectedRow;
	}

	@Override
	public String toString() {
		return "PassengerFinished [affectedRow=" + affectedRow + "]";
	}
	
	
}