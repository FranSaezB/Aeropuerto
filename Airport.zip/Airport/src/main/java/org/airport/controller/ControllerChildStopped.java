package org.airport.controller;

public class ControllerChildStopped implements AirportInteraction{

	public ControllerChildStopped(String string) {
		
	}
	
	

}
