package org.airport.controller.rowManager;

import java.util.List;

import org.airport.Passenger;
import org.airport.controller.AirportPrivateInteraction;

public class PassengersNotification implements AirportPrivateInteraction {
	
	public final List<Passenger> passengers;

	public PassengersNotification(List<Passenger> passengers) {
		super();
		this.passengers = passengers;
	}

	public List<Passenger> getPassengers() {
		return passengers;
	}

	@Override
	public String toString() {
		return "PassengersNotification [passengers=" + passengers + "]";
	}


}
