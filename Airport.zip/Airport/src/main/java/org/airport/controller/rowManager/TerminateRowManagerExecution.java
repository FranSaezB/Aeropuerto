package org.airport.controller.rowManager;

import org.airport.controller.AirportPrivateInteraction;

public class TerminateRowManagerExecution implements AirportPrivateInteraction {

	public TerminateRowManagerExecution() {
		super();
		
	}
	
	

}
