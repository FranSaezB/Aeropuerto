package org.airport.controller;

import org.airport.controller.conveyor.Conveyor;
import org.airport.controller.conveyor.InitializeConveyor;
import org.airport.controller.conveyor.TerminateConveyorExecution;
import org.airport.controller.employeeManager.EmployeeManager;
import org.airport.controller.employeeManager.TerminateEmployeeManagerExecution;
import org.airport.controller.rowManager.PassengersNotification;
import org.airport.controller.rowManager.RowManager;
import org.airport.controller.rowManager.RowsReferencesRequest;
import org.airport.controller.rowManager.TerminateRowManagerExecution;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

public class AirportController extends AbstractBehavior<AirportInteraction> {

	private final ActorRef<AirportPrivateInteraction> rowManager;
	private final ActorRef<AirportPrivateInteraction> conveyor;
	private final ActorRef<AirportPrivateInteraction> employeeManager;
	private ActorRef<AirportInteraction> interested;

	private int terminatedCounter = 0;

	public static Behavior<AirportInteraction> create() {
		return Behaviors.setup(AirportController::new);
	}

	private AirportController(ActorContext<AirportInteraction> context) {
		super(context);
		this.getContext().getSystem();
		// #create-actors
		rowManager = context.spawn(RowManager.create(this.getContext().getSelf()), "row_manager");
		conveyor = context.spawn(Conveyor.create(this.getContext().getSelf()), "conveyor");
		employeeManager = context.spawn(EmployeeManager.create(conveyor, this.getContext().getSelf()),
				"employee_manager");

		this.getContext().watchWith(rowManager, new ControllerChildStopped("row"));
		this.getContext().watchWith(conveyor, new ControllerChildStopped("conveyor"));
		this.getContext().watchWith(employeeManager, new ControllerChildStopped("employee"));
	
		rowManager.tell(new RowsReferencesRequest(conveyor));
		// #create-actors
	}

	@Override
	public Receive<AirportInteraction> createReceive() {

		return newReceiveBuilder().onMessage(OpenAirport.class, this::onOpenAirport)
				.onMessage(PassengersNotification.class, this::onPassengerNotification)
				.onMessage(ConveyorReady.class, this::onConveyorReady)
				.onMessage(TerminateExecutionCommand.class, this::onTerminateExecutionCommand)
				.onMessage(ControllerChildStopped.class, this::onControllerChildStopped).build();
	}

	private Behavior<AirportInteraction> onTerminateExecutionCommand(TerminateExecutionCommand command) {

//		System.out.println("AirportController.onTerminateExecutionNotification (" + command + " )");

		this.rowManager.tell(new TerminateRowManagerExecution());
		this.employeeManager.tell(new TerminateEmployeeManagerExecution());
		this.conveyor.tell(new TerminateConveyorExecution());

		return this;
	}

	private Behavior<AirportInteraction> onControllerChildStopped(ControllerChildStopped command) {

		terminatedCounter++;

		if (terminatedCounter == 3) {

			System.out.println("TERMINATING CONTROLLER\n");

			this.getContext().getSystem().terminate();

			return Behaviors.stopped();

		} else {

			return this;

		}

	}

	private Behavior<AirportInteraction> onConveyorReady(ConveyorReady command) {
		
		System.out.println("AIRPORT READY");

		this.interested.tell(new AirportReady());

		return this;
	}

	private Behavior<AirportInteraction> onPassengerNotification(PassengersNotification command) {

		rowManager.tell(command);

		return this;
	}

	private Behavior<AirportInteraction> onOpenAirport(OpenAirport command) {

		System.out.println("OPENING THE AIRPORT\n");

		conveyor.tell(new InitializeConveyor(command.getSize()));

		this.interested = command.getCalled();

		return this;
	}

}
