package org.airport.controller;

public class TerminateExecutionCommand implements AirportPrivateInteraction {

	public TerminateExecutionCommand() {
		super();

	}

}