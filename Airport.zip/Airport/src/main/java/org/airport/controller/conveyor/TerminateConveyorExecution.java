package org.airport.controller.conveyor;

import org.airport.controller.AirportPrivateInteraction;

public class TerminateConveyorExecution implements AirportPrivateInteraction {

	public TerminateConveyorExecution() {
		super();
	}

}
