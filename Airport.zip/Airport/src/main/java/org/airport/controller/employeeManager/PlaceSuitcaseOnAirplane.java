package org.airport.controller.employeeManager;

import org.airport.controller.AirportPrivateInteraction;

public class PlaceSuitcaseOnAirplane implements AirportPrivateInteraction {

	public PlaceSuitcaseOnAirplane() {
		super();

	}

}