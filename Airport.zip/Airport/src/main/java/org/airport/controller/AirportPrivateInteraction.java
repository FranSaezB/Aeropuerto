package org.airport.controller;

public interface AirportPrivateInteraction extends AirportInteraction {

}
