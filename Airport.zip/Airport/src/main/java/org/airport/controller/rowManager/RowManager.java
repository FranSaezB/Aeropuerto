package org.airport.controller.rowManager;

import java.util.ArrayList;
import java.util.List;

import org.airport.Passenger;
import org.airport.controller.AirportInteraction;
import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

// #greeter
public class RowManager extends AbstractBehavior<AirportPrivateInteraction> {

	private List<Integer> rowSizes = new ArrayList<>();
	private final List<ActorRef<AirportPrivateInteraction>> rows = new ArrayList<>();
	private final ActorRef<AirportInteraction> airportController;
	private int terminatedCounter = 0;

	public static Behavior<AirportPrivateInteraction> create(ActorRef<AirportInteraction> airportController) {
		return Behaviors.setup(param -> {
			return new RowManager(param, airportController);
		});
	}

	private RowManager(ActorContext<AirportPrivateInteraction> context,
			ActorRef<AirportInteraction> airportController) {
		super(context);

		this.airportController = airportController;

		rows.add(this.getContext().spawn(Row.create(this.getContext().getSelf()), "0"));
		rows.add(this.getContext().spawn(Row.create(this.getContext().getSelf()), "1"));
		rows.add(this.getContext().spawn(Row.create(this.getContext().getSelf()), "2"));
		rows.add(this.getContext().spawn(Row.create(this.getContext().getSelf()), "3"));
		rows.add(this.getContext().spawn(Row.create(this.getContext().getSelf()), "4"));
		rows.add(this.getContext().spawn(Row.create(this.getContext().getSelf()), "5"));
		rows.add(this.getContext().spawn(Row.create(this.getContext().getSelf()), "6"));
		
		this.getContext().watchWith(rows.get(0), new RowStopped());
		this.getContext().watchWith(rows.get(1), new RowStopped());
		this.getContext().watchWith(rows.get(2), new RowStopped());
		this.getContext().watchWith(rows.get(3), new RowStopped());
		this.getContext().watchWith(rows.get(4), new RowStopped());
		this.getContext().watchWith(rows.get(5), new RowStopped());
		this.getContext().watchWith(rows.get(6), new RowStopped());

		rowSizes.add(0);
		rowSizes.add(0);
		rowSizes.add(0);
		rowSizes.add(0);
		rowSizes.add(0);
		rowSizes.add(0);
		rowSizes.add(0);

	}

	@Override
	public Receive<AirportPrivateInteraction> createReceive() {

		return newReceiveBuilder().onMessage(PassengersNotification.class, this::onPassengersNotification)
				.onMessage(PassengerFinished.class, this::onPassengerFinished)
				.onMessage(RowsReferencesRequest.class, this::onRowsReferencesRequest)
				.onMessage(TerminateRowManagerExecution.class, this::onTerminateExecutionCommand)
				.onMessage(RowStopped.class, this::onRowStopped)
				.build();
	}

	private Behavior<AirportPrivateInteraction> onTerminateExecutionCommand(
			TerminateRowManagerExecution command) {
		
		System.out.println("NOTIFICATION TO STOP THE ROW MANAGER");


		for (int i = 0; i < rows.size(); i++) {

			rows.get(i).tell(command);

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onRowStopped(RowStopped command) {
		
		System.out.println("Rows stopped: "+(this.terminatedCounter+1));
		
		this.terminatedCounter++;

		if (terminatedCounter == 7) {
			
			System.out.println("STOPPING ROWMANAGER");

			return Behaviors.stopped();

		} else {

			return this;

		}

	}

	private Behavior<AirportPrivateInteraction> onRowsReferencesRequest(RowsReferencesRequest command) {

//		System.out.println("RowManager.onRowsReferencesRequest (" + command + " )");

		command.getInterested().tell(new RowsReferencesNotification(this.rows));

		return this;
	}

	private Behavior<AirportPrivateInteraction> onPassengersNotification(PassengersNotification command) {

//		System.out.println("RowManager.onPassengersNotification (" + command + " )");

		assignPassengers(command.getPassengers());

		return this;
	}

	private void assignPassengers(List<Passenger> passengers) {

		while (!passengers.isEmpty()) {

			int lowestSize = lowestSize();

			rows.get(lowestSize).tell(new AssignPassengerToRow(passengers.remove(0), getContext().getSelf()));

			rowSizes.set(lowestSize, rowSizes.get(lowestSize) + 1);

		}

	}

	private int lowestSize() {

		int minIndex = 0;
		int lowestSize = this.rowSizes.get(0);

		for (int i = 1; i < 7; i++) {

			if (lowestSize > this.rowSizes.get(i)) {

				lowestSize = this.rowSizes.get(i);
				minIndex = i;

			}

		}

//		System.out.println("RowManger.lowestSize: " + minIndex);

		return minIndex;

	}

	private Behavior<AirportPrivateInteraction> onPassengerFinished(PassengerFinished command) {

//		System.out.println("RowManager.onPassengerFinished (" + command + " )");

		int rowIndex = command.getAffectedRow();

		this.rowSizes.set(rowIndex, this.rowSizes.get(rowIndex) - 1);

		return this;
	}

}
// #greeter
