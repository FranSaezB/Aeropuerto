package org.airport.controller.employeeManager;

import org.airport.controller.AirportPrivateInteraction;

public class AddWorkersRequest implements AirportPrivateInteraction {

	public AddWorkersRequest() {
		super();

	}

}