package org.airport.controller.employeeManager;

import org.airport.Airplane;
import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

// #greeter
public class Employee extends AbstractBehavior<AirportPrivateInteraction> {

	private final ActorRef<AirportPrivateInteraction> employeeManager;

	private final ActorRef<AirportPrivateInteraction> conveyor;

	private final Airplane airplane;

	public static Behavior<AirportPrivateInteraction> create(ActorRef<AirportPrivateInteraction> employeeManager,
			Airplane airplane, ActorRef<AirportPrivateInteraction> conveyor) {
		return Behaviors.setup(param -> {
			return new Employee(param, employeeManager, airplane, conveyor);
		});
	}

	private Employee(ActorContext<AirportPrivateInteraction> context,
			ActorRef<AirportPrivateInteraction> employeeManager, Airplane airplane,
			ActorRef<AirportPrivateInteraction> conveyor) {
		super(context);
		this.employeeManager = employeeManager;
		this.conveyor = conveyor;
		this.airplane = airplane;

		this.conveyor.tell(new EmployeeReady(this.getContext().getSelf(), this.employeeManager));

	}

	@Override
	public Receive<AirportPrivateInteraction> createReceive() {

		return newReceiveBuilder().onMessage(PlaceSuitcaseOnAirplane.class, this::onPlaceSuitcaseOnAirplane)
				.onMessage(TerminateEmployeeManagerExecution.class, this::onTerminateExecutionNotification).build();
	}

	private Behavior<AirportPrivateInteraction> onTerminateExecutionNotification(
			TerminateEmployeeManagerExecution command) {
		
		System.out.println("Stopping actor " +this.getContext().getSelf().path().name());

		return Behaviors.stopped();
	}

	private Behavior<AirportPrivateInteraction> onPlaceSuitcaseOnAirplane(PlaceSuitcaseOnAirplane command)
			throws InterruptedException {

//		System.out.println("Employee.onPlaceSuitcaseOnAirplane (" + command + " )");
		
		System.out.println(this.getContext().getSelf().path().name() + " is placing a suitcase in the airplane");

		airplane.setSuitcaseCounter(airplane.getSuitcaseCounter() + 1);

		System.out.println("Current size of the airplane: " + airplane.getSuitcaseCounter());

		int rand = (int) (Math.random() * (7000 - 2000) + 200);

		Thread.sleep(rand);

		conveyor.tell(new EmployeeReady(this.getContext().getSelf(), this.employeeManager));

		return this;
	}

}
// #greeter
