package org.airport.controller.rowManager;

import java.util.ArrayList;
import java.util.List;

import org.airport.Passenger;
import org.airport.controller.AirportPrivateInteraction;
import org.airport.controller.conveyor.SuitcaseProcessed;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

// #greeter
public class Row extends AbstractBehavior<AirportPrivateInteraction> {

	private List<Passenger> passengers = new ArrayList<Passenger>();

	private ActorRef<AirportPrivateInteraction> rowManager;

	public static Behavior<AirportPrivateInteraction> create(ActorRef<AirportPrivateInteraction> rowManager) {

		return Behaviors.setup(param -> {
			return new Row(param, rowManager);
		});
	}

	private Row(ActorContext<AirportPrivateInteraction> context, ActorRef<AirportPrivateInteraction> rowManager) {
		super(context);
		this.rowManager = rowManager;
	}

	@Override
	public Receive<AirportPrivateInteraction> createReceive() {
		return newReceiveBuilder().onMessage(AssignPassengerToRow.class, this::onAssignPassengerToRow)
				.onMessage(NextPassengerRequest.class, this::onNextPassengerRequest)
				.onMessage(SuitcaseProcessed.class, this::onSuitcaseProcessed)
				.onMessage(TerminateRowManagerExecution.class, this::onTerminateExecutionNotification).build();
	}

	private Behavior<AirportPrivateInteraction> onTerminateExecutionNotification(
			TerminateRowManagerExecution command) {

		System.out.println("Stopping actor Row [" +  this.getContext().getSelf().path().name()+"]");

		return Behaviors.stopped();
	}

	private Behavior<AirportPrivateInteraction> onAssignPassengerToRow(AssignPassengerToRow command) {

//		System.out.println(
//				"Row [ " + this.getContext().getSelf().path().name() + " ].onAssignPassengerToRow (" + command + " )");

		Passenger passenger = command.getPassenger();

		passengers.add(passenger);

		return this;
	}

	private Behavior<AirportPrivateInteraction> onSuitcaseProcessed(SuitcaseProcessed command) {

//		System.out.println(
//				"Row [ " + this.getContext().getSelf().path().name() + " ].onSuitcaseProcessed (" + command + " )");

		Passenger firstPassenger = passengers.get(0);

		firstPassenger.setSuitcases(firstPassenger.getSuitcases() - 1);

		if (firstPassenger.getSuitcases() == 0) {

			passengers.remove(0);

			rowManager.tell(new PassengerFinished(Integer.valueOf(this.getContext().getSelf().path().name())));

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onNextPassengerRequest(NextPassengerRequest command) {

//		System.out.println(
//				"Row [ " + this.getContext().getSelf().path().name() + " ].onNextPassengerRequest (" + command + " )");

		if (passengers.isEmpty()) {

			command.getInterested().tell(new EmptyRow());

		} else {

			command.getInterested()
					.tell(new NextPassengerNotification(Integer.valueOf(this.getContext().getSelf().path().name())));

		}

		return this;
	}
}
// #greeter
