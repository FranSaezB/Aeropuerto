package org.airport.controller.rowManager;

import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;

public class RowsReferencesRequest implements AirportPrivateInteraction {
	
	public final ActorRef<AirportPrivateInteraction> interested;
	
	public RowsReferencesRequest(ActorRef<AirportPrivateInteraction> interested) {
		super();
		this.interested = interested;
	}

	public ActorRef<AirportPrivateInteraction> getInterested() {
		return interested;
	}

}
