package org.airport.controller.rowManager;

import org.airport.Passenger;
import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;

public final class AssignPassengerToRow implements AirportPrivateInteraction {

	public final Passenger passenger;

	public final ActorRef<AirportPrivateInteraction> rowManager;

	public AssignPassengerToRow(Passenger passenger, ActorRef<AirportPrivateInteraction> rowManager) {

		this.passenger = passenger;

		this.rowManager = rowManager;

	}

	public Passenger getPassenger() {
		return passenger;
	}

	@Override
	public String toString() {
		return "PassengerSender [passenger=" + passenger + "]";
	}

	public ActorRef<AirportPrivateInteraction> getRowManager() {
		return rowManager;
	}

}