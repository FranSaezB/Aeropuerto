package org.airport.controller.employeeManager;

import org.airport.controller.AirportPrivateInteraction;

public class EmployeeStopped implements AirportPrivateInteraction{

}
