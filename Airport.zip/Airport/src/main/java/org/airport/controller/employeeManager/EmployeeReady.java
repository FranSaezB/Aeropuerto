package org.airport.controller.employeeManager;

import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;

public class EmployeeReady implements AirportPrivateInteraction {

	public final ActorRef<AirportPrivateInteraction> affectedEmployee;

	public final ActorRef<AirportPrivateInteraction> affectedEmployeeManager;

	public EmployeeReady(ActorRef<AirportPrivateInteraction> affectedEmployee,
			ActorRef<AirportPrivateInteraction> affectedEmployeeManager) {
		super();

		this.affectedEmployee = affectedEmployee;
		this.affectedEmployeeManager = affectedEmployeeManager;

	}

	public ActorRef<AirportPrivateInteraction> getAffectedEmployee() {
		return affectedEmployee;
	}

	public ActorRef<AirportPrivateInteraction> getAffectedEmployeeManager() {
		return affectedEmployeeManager;
	}

}