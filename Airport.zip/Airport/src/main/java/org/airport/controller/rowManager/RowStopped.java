package org.airport.controller.rowManager;

import org.airport.controller.AirportPrivateInteraction;

public class RowStopped implements AirportPrivateInteraction {

}
