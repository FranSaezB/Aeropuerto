package org.airport.controller.conveyor;

import org.airport.controller.AirportPrivateInteraction;

public class SlotStopped implements AirportPrivateInteraction {

}
