package org.airport.controller.conveyor;

import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;

public class TaskNotDoneEmptySlot implements AirportPrivateInteraction {

	public final ActorRef<AirportPrivateInteraction> affectedEmployee;

	public TaskNotDoneEmptySlot(ActorRef<AirportPrivateInteraction> affectedEmployee) {
		super();

		this.affectedEmployee = affectedEmployee;

	}

	public ActorRef<AirportPrivateInteraction> getAffectedEmployee() {
		return affectedEmployee;
	}

}