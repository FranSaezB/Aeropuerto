package org.airport.controller.rowManager;

import java.util.List;

import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;

public class RowsReferencesNotification implements AirportPrivateInteraction {

	public final List<ActorRef<AirportPrivateInteraction>> rowsReferences;

	public RowsReferencesNotification(List<ActorRef<AirportPrivateInteraction>> rowsReferences) {
		super();
		this.rowsReferences = rowsReferences;
	}

	public List<ActorRef<AirportPrivateInteraction>> getRowsReferences() {
		return rowsReferences;
	}

}
