package org.airport.controller;

public class AirportReady implements AirportInteraction {

	@Override
	public int hashCode() {

		return 1;
	}

	@Override
	public boolean equals(Object obj) {

		if (obj instanceof AirportReady) {

			return true;

		}

		return false;
	}

}
