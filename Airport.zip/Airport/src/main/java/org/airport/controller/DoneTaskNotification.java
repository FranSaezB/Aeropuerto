package org.airport.controller;

public class DoneTaskNotification implements AirportPrivateInteraction {
	
	private final String affectedSlot;

	public DoneTaskNotification(String affectedSlot) {
		super();
		
		this.affectedSlot = affectedSlot;

	}

	public String getAffectedSlot() {
		return affectedSlot;
	}
	
	

}