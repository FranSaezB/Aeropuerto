package org.airport.controller;

import akka.actor.typed.ActorRef;

public class OpenAirport implements AirportInteraction {

	public final int size;
	public final String name;
	public final ActorRef<AirportInteraction> called;

	@SuppressWarnings("unchecked")
	public OpenAirport(String name, int size, ActorRef<? extends AirportInteraction> called) {
		super();
		this.size = size;
		this.name = name;
		this.called = (ActorRef<AirportInteraction>) called;
	}

	public int getSize() {
		return size;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "OpenAirport [size=" + size + ", name=" + name + "]";
	}

	public ActorRef<AirportInteraction> getCalled() {
		return called;
	}

}