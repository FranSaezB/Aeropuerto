package org.airport.controller.conveyor;

import org.airport.controller.AirportPrivateInteraction;

public class InitializeConveyor implements AirportPrivateInteraction {

	public final int size;

	public InitializeConveyor(int size) {
		super();
		this.size = size;
	}

	public int getSize() {
		return size;
	}

	@Override
	public String toString() {
		return "InitializeConveyor [size=" + size + "]";
	}

}
