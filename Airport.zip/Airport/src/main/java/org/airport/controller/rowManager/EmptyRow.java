package org.airport.controller.rowManager;

import org.airport.controller.AirportPrivateInteraction;

public class EmptyRow implements AirportPrivateInteraction {

	public EmptyRow() {
		super();
	}

}