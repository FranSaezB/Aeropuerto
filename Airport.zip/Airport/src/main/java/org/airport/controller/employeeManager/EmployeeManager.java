package org.airport.controller.employeeManager;

import java.util.ArrayList;
import java.util.List;

import org.airport.Airplane;
import org.airport.controller.AirportInteraction;
import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

// #greeter
public class EmployeeManager extends AbstractBehavior<AirportPrivateInteraction> {

	private final ActorRef<AirportInteraction> airportController;

	private final ActorRef<AirportPrivateInteraction> conveyor;

	private final List<ActorRef<AirportPrivateInteraction>> employees = new ArrayList<>();

	private int terminatedCounter = 0;

	private boolean working = true;

	private final Airplane airplane;

	private int scalingSize = 2;

	public static Behavior<AirportPrivateInteraction> create(ActorRef<AirportPrivateInteraction> conveyor,
			ActorRef<AirportInteraction> airportController) {
		return Behaviors.setup(param -> {
			return new EmployeeManager(param, conveyor, airportController);
		});
	}

	private EmployeeManager(ActorContext<AirportPrivateInteraction> context,
			ActorRef<AirportPrivateInteraction> conveyor, ActorRef<AirportInteraction> airportController) {
		super(context);

		this.airportController = airportController;

		this.conveyor = conveyor;

		this.airplane = new Airplane();

		this.employees.add(
				this.getContext().spawn(Employee.create(this.getContext().getSelf(), airplane, conveyor), "employee0"));

		this.getContext().watchWith(employees.get(0), new EmployeeStopped());

		this.employees.add(
				this.getContext().spawn(Employee.create(this.getContext().getSelf(), airplane, conveyor), "employee1"));

		this.getContext().watchWith(employees.get(1), new EmployeeStopped());

	}

	@Override
	public Receive<AirportPrivateInteraction> createReceive() {

		return newReceiveBuilder().onMessage(AddWorkersRequest.class, this::onAddWorkersRequest)
				.onMessage(TerminateEmployeeManagerExecution.class, this::onTerminateExecutionCommand)
				.onMessage(EmployeeStopped.class, this::onEmployeeStopped).build();
	}

	private Behavior<AirportPrivateInteraction> onTerminateExecutionCommand(TerminateEmployeeManagerExecution command) {

		System.out.println("NOTIFICATION TO STOP EMPLOYEE MANAGER");

		for (int i = 0; i < employees.size(); i++) {

			employees.get(i).tell(command);

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onEmployeeStopped(EmployeeStopped command) {

		System.out.println("Employees stopped: " + (this.terminatedCounter + 1));

		if (!working) {

			System.out.println("EmployeeManager.onAddWorkersRequest After Stopped");

			return Behaviors.stopped();

		}

		this.terminatedCounter++;

		if (terminatedCounter == scalingSize) {

			this.working = false;

			System.out.println("STOPPING EMPLOYEE MANAGER");

			return Behaviors.stopped();

		} else {

			return this;

		}

	}

	private Behavior<AirportPrivateInteraction> onAddWorkersRequest(AddWorkersRequest command) {

		if (!working) {

			System.out.println("REQUEST TO ADD NEW WORKERS After Stopped");

			return Behaviors.stopped();

		}

		System.out.println("REQUEST TO ADD NEW WORKERS");

		int idNumber = this.scalingSize;

		for (int i = 1; i < 3; i++) {

			idNumber += 1;

			this.employees.add(this.getContext().spawn(Employee.create(this.getContext().getSelf(), airplane, conveyor),
					"employee" + idNumber));

			this.getContext().watchWith(employees.get(employees.size() - 1), new EmployeeStopped());

			this.scalingSize++;

		}

		System.out.println("TOTAL NUMBER OF WORKERS AFTER SCALLING: " + employees.size());

		return this;
	}

}
// #greeter
