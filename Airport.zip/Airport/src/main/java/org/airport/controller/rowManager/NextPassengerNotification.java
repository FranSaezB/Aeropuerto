package org.airport.controller.rowManager;

import org.airport.controller.AirportPrivateInteraction;

public class NextPassengerNotification implements AirportPrivateInteraction {

	public final int affectedRow;

	public NextPassengerNotification(int affectedRow) {
		super();

		this.affectedRow = affectedRow;

	}

	public int getAffectedRow() {
		return affectedRow;
	}

}