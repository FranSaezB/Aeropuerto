package org.airport.controller.conveyor;

import org.airport.controller.AirportPrivateInteraction;

public class LocateSuitcaseRequest implements AirportPrivateInteraction {

	public LocateSuitcaseRequest() {
		super();

	}

}