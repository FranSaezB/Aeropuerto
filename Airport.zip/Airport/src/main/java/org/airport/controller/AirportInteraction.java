package org.airport.controller;

public interface AirportInteraction {

}
