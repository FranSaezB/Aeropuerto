package org.airport.controller.rowManager;

import org.airport.controller.AirportPrivateInteraction;

import akka.actor.typed.ActorRef;

public class NextPassengerRequest implements AirportPrivateInteraction {

	public final ActorRef<AirportPrivateInteraction> interested;

	public NextPassengerRequest(ActorRef<AirportPrivateInteraction> interested) {
		super();

		this.interested = interested;
	}

	public ActorRef<AirportPrivateInteraction> getInterested() {
		return interested;
	}

}