package org.airport.controller;

public class ConveyorReady implements AirportPrivateInteraction {

}
