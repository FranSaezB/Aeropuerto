package org.airport.controller.conveyor;

import org.airport.controller.AirportPrivateInteraction;
import org.airport.controller.DoneTaskNotification;
import org.airport.controller.employeeManager.PlaceSuitcaseOnAirplane;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

public class Slot extends AbstractBehavior<AirportPrivateInteraction> {

	private ActorRef<AirportPrivateInteraction> conveyor;
	private String innerState;

	public static Behavior<AirportPrivateInteraction> create(ActorRef<AirportPrivateInteraction> conveyor) {

		return Behaviors.setup(param -> {
			return new Slot(param, conveyor);
		});
	}

	private Slot(ActorContext<AirportPrivateInteraction> context, ActorRef<AirportPrivateInteraction> conveyor) {
		super(context);
		this.conveyor = conveyor;
		this.innerState = "empty";
	}

	@Override
	public Receive<AirportPrivateInteraction> createReceive() {

		return newReceiveBuilder().onMessage(LocateSuitcaseRequest.class, this::onLocateSuitcaseRequest)
				.onMessage(PickSuitcaseRequest.class, this::onPickSuitcaseRequest)
				.onMessage(TerminateConveyorExecution.class, this::onTerminateExecutionNotification)
				.build();
	}
	
	private Behavior<AirportPrivateInteraction> onTerminateExecutionNotification(
			TerminateConveyorExecution command) {
		
		System.out.println("Stopping actor " +this.getContext().getSelf().path().name());

		return Behaviors.stopped();
	}

	private Behavior<AirportPrivateInteraction> onLocateSuitcaseRequest(LocateSuitcaseRequest command) {

//		System.out.println("Slot [ " + this.getContext().getSelf().path().name() + " ].onLocateSuitcaseRequest ("
//				+ command + " )");

		if (this.innerState.equals("empty")) {

			this.innerState = "filled";

			conveyor.tell(new DoneTaskNotification(this.getContext().getSelf().path().name()));

		} else {

			conveyor.tell(new TaskNotDoneFilledSlot());

		}

		return this;
	}

	private Behavior<AirportPrivateInteraction> onPickSuitcaseRequest(PickSuitcaseRequest command) {

//		System.out.println(
//				"Slot [ " + this.getContext().getSelf().path().name() + " ].onPickSuitcaseRequest (" + command + " )");

		if (this.innerState.equals("empty")) {

			conveyor.tell(new TaskNotDoneEmptySlot(command.getAffectedEmployee()));

		} else {

			command.getAffectedEmployee().tell(new PlaceSuitcaseOnAirplane());

			this.innerState = "empty";

			conveyor.tell(new DoneTaskNotification(this.getContext().getSelf().path().name()));

		}

		return this;
	}

}
