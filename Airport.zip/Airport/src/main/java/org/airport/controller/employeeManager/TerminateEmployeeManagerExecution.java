package org.airport.controller.employeeManager;

import org.airport.controller.AirportPrivateInteraction;

public class TerminateEmployeeManagerExecution implements AirportPrivateInteraction {

	public TerminateEmployeeManagerExecution() {
		super();

	}

}
