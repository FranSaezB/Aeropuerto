package com.example;

import org.airport.controller.AirportController;
import org.airport.controller.AirportInteraction;
import org.airport.controller.AirportReady;
import org.airport.controller.OpenAirport;
import org.junit.ClassRule;
import org.junit.Test;

import akka.actor.testkit.typed.javadsl.TestKitJunitResource;
import akka.actor.testkit.typed.javadsl.TestProbe;
import akka.actor.typed.ActorRef;

//#definition
public class AkkaQuickstartTest {

	@ClassRule
	public static final TestKitJunitResource testKit = new TestKitJunitResource();


	@Test
	public void testOpenAirport() {

		TestProbe<AirportInteraction> testProbe = testKit.createTestProbe();
		ActorRef<AirportInteraction> underTest = testKit.spawn(AirportController.create(), "airport");
		underTest.tell(new OpenAirport("Testname", 8, testProbe.getRef()));
		testProbe.expectMessage(new AirportReady());
	}

//	@Test
//	public void testInitializeConveyor() {
//
//		TestProbe<AirportInteraction> testProbe = testKit.createTestProbe();
//		ActorRef<AirportPrivateInteraction> employeeManager = testKit.spawn(EmployeeManager.create(testProbe.getRef()),
//				"employeeManager");
//		ActorRef<AirportPrivateInteraction> underTest = testKit
//				.spawn(Conveyor.create(employeeManager, testProbe.getRef()), "airport");
//		underTest.tell(new InitializeConveyor(8));
//		testProbe.expectMessage(new ConveyorReady());
//	}

	// #test
}
