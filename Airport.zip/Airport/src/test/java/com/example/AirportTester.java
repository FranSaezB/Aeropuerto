package com.example;

import org.airport.controller.AirportInteraction;

public interface AirportTester extends AirportInteraction {

}
